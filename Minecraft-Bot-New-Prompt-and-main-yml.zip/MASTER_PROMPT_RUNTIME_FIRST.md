# MASTER PROMPT — Minecraft Bot Android Rebuild (Runtime-First, No Fake Features)

You are a senior Android/Kotlin, React Native, Node.js runtime, Minecraft Java/Bedrock protocol, and CI/CD engineer.

## Project input
Use the repository's existing files as the source of truth:
- `App.tsx`
- `index.js`
- `package.json`
- `android-native/`
- `scripts/patch-generated-android.py`
- `nodejs-assets/nodejs-project/`
- `KNOWN-LIMITATIONS.md`
- `.github/workflows/main.yml`

The recovered Minecraft bot engine includes JavaScript modules and dependencies such as Mineflayer, bedrock-protocol, minecraft-data, and mineflayer-pathfinder. Preserve the actual recovered modules. Do not replace them with a fake/demo bot.

## Primary goal
Deliver an installable Android APK that can genuinely connect a bot to a user-authorized Minecraft Java or Bedrock server from an Android phone.

A green GitHub Actions build is not proof of a working server connection. Do not claim completion until a real device test confirms the connection.

## Phase 1 — Audit before editing
1. Inspect every project file and the complete `nodejs-assets/nodejs-project/package.json` and lockfile.
2. Trace the real entry point (`bootstrap.js` / `main.js`) and every `rn-bridge` import/call.
3. List all JavaScript dependencies, native addons, Node APIs, network transports, and authentication paths.
4. Inspect the actual embedded Node runtime version inside the Android runtime package.
5. Inspect dependency `engines.node` requirements.
6. Produce a compatibility table: dependency, required Node version, native code/ABI needs, Android compatibility, test evidence.
7. Do not infer the embedded runtime version from the Node.js version installed on GitHub Actions.

## Phase 2 — Resolve the runtime blocker
The current template uses `nodejs-mobile-react-native` 18.20.4, while the recovered Mineflayer dependency tree declares Node.js 22 or newer.

This is a release-blocking incompatibility. Resolve it without pretending that CI's Node 22 fixes the Node runtime embedded in the APK.

Evaluate and implement one technically valid route:
- Upgrade/build a Node.js 22+ Android runtime for supported Android ABIs (at minimum arm64-v8a), including reproducible source/build scripts and licensing notices; OR
- Select a maintained Android runtime that demonstrably embeds Node.js 22+ and supports the required Node APIs; OR
- If neither is feasible, stop and provide a precise blocker report rather than shipping a misleading APK.

Do not silently downgrade Mineflayer or remove recovered features to make installation pass. Any dependency downgrade must be justified by API/protocol compatibility tests and approved explicitly.

## Phase 3 — Native bridge
Implement and test the bridge between the Android app and the Node runtime:
- Start the runtime exactly once.
- Send structured JSON commands from UI to engine.
- Receive structured JSON events from engine.
- Support runtime-ready, startup-failed, log, connecting, authenticated, connected, disconnected, kicked, and error events.
- Prevent duplicate bot instances.
- Ensure Stop destroys the bot, sockets, timers, and listeners.
- Never set UI status to Connected until the underlying protocol client emits a verified connected/spawn/login event.
- Do not log access tokens, passwords, device codes, or other secrets.

If the original `rn-bridge` native host is missing, implement a documented replacement adapter and update all call sites consistently. Do not leave a mock bridge in production code.

## Phase 4 — Minecraft Java Edition
Implement the actual recovered Mineflayer path:
- Host, port, username, version auto-detection.
- Offline authentication only where the target server permits it.
- Microsoft authentication using a supported official device-code flow where available.
- Clear authentication errors and user-facing instructions.
- Actual login/spawn confirmation.
- Disconnect and reconnect lifecycle.
- Correct handling of server version and protocol errors.

Do not bypass authentication, server access controls, allowlists, or anti-cheat. Do not attempt to evade server rules.

## Phase 5 — Minecraft Bedrock Edition
Implement the actual recovered bedrock-protocol path:
- Host, UDP port, username, protocol version.
- Validate RakNet/UDP transport and DNS behavior on Android.
- Handle supported authentication mode.
- Confirm successful Bedrock login using a real protocol event.
- Surface unsupported protocol/authentication errors accurately.

Do not label a Bedrock connection successful merely because a UDP socket opened.

## Phase 6 — Android application
Keep a clean, responsive dashboard with:
- Java / Bedrock selector.
- Server address and port.
- Username and authentication selection.
- Join / Stop controls.
- Runtime status and actual bot connection status.
- Live logs with secret redaction.
- Save/restore non-secret configuration.
- Foreground service and ongoing notification while a user-started bot session runs.
- Correct Android notification and foreground-service permissions for the chosen target SDK.
- Graceful cleanup and process/activity lifecycle handling.
- Clear warning that Android battery management may stop long-running work.

Do not promise guaranteed 24/7 operation on all Android phones.

## Phase 7 — CI/CD and tests
Update `.github/workflows/main.yml` to:
1. Check out the repository.
2. Install the required JDK, Android SDK/NDK, Python, and build-time Node.
3. Install root React Native dependencies.
4. Install recovered bot dependencies from the lockfile.
5. Run JavaScript syntax checks and TypeScript checks.
6. Run unit tests and bridge protocol tests.
7. Verify that the Android-embedded Node runtime version satisfies all production dependencies.
8. Fail the release build if the runtime compatibility audit fails.
9. Bundle React Native JS for a standalone APK.
10. Build the APK.
11. Upload APK and useful diagnostics as workflow artifacts.

Important: Node installed by `actions/setup-node` is only a build tool. It does not change the Node version embedded in `nodejs-mobile-react-native`.

## Phase 8 — Required real-device test evidence
Create a test checklist and record actual results for:
- Install and first launch on Android.
- Runtime startup and reported embedded Node version.
- Java offline-mode connection to a test server that explicitly allows it.
- Java Microsoft-authenticated connection, if supported.
- Bedrock connection to a test server.
- Successful login/spawn event.
- Stop and reconnect.
- App backgrounding, screen off, notification, and service cleanup.
- ARM64 device compatibility.
- No credentials/tokens in logs.

If no physical device or test server is available, mark the test NOT RUN. Never fabricate successful test evidence.

## Deliverables
- Complete source project.
- Reproducible Android Node runtime integration or a clearly documented blocker.
- Working native bridge.
- Updated `main.yml`.
- Dependency/runtime compatibility report.
- Unit and integration tests.
- README with phone-based GitHub upload/build/download steps.
- Debug APK artifact; signed release APK only when signing secrets are configured.
- `KNOWN-LIMITATIONS.md` updated with evidence.

## Definition of done
The project is only “fully working” after a compatible embedded Node runtime is verified, the real JavaScript engine starts, and a real Android device successfully joins and leaves at least one authorized Minecraft Java server and one authorized Bedrock server (if both editions are claimed). Compilation alone is insufficient.

Developer credit: Tanvir.
